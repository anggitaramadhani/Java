package projectpbo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class TotalNilaiModel {
    TotalNilaiView view;
    LihatRekapNilaiController controller;
    String DBurl = "jdbc:mysql://localhost/datamahasiswa";
    String DBusername = "root";
    String DBpassword = "";
    Connection koneksi;
    Statement statement;
    ResultSet resultset;
    
    public void TotalNilai(TotalNilaiView view){
        try {
            Class.forName("com.mysql.jdbc.Driver");
            koneksi = DriverManager.getConnection(DBurl,DBusername,DBpassword);
            statement = koneksi.createStatement();
            String sql = "select * from rekapnilai";
            resultset = statement.executeQuery(sql);
            int a = 0;
            while (resultset.next()){
                view.tugas[a] = resultset.getFloat("NilaiTugas");
                view.uts[a] = resultset.getFloat("NilaiUTS");
                view.uas[a] = resultset.getFloat("NilaiUAS");
                view.nilaiakhir[a] = (35*view.tugas[a] + 35*view.uts[a] + 30*view.uas[a])/100;
                view.rekapnilai[a][0] = resultset.getString("MataKuliah");
                view.rekapnilai[a][1] = String.valueOf(view.nilaiakhir[a]);
                a++;
            }
        }catch (SQLException ex) {
            Logger.getLogger(TotalNilaiController.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Data Gagal Ditemukan!!");
        }catch (ClassNotFoundException ex) {
            Logger.getLogger(TotalNilaiController.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Driver Tidak Ditemukan!!");
        }
    }
}


