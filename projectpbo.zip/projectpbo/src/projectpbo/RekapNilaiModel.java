package projectpbo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class RekapNilaiModel {
    String DBurl = "jdbc:mysql://localhost/datamahasiswa";
    String DBusername = "root";
    String DBpassword = "";
    RekapNilaiView view;
    ResultSet resultset;
    Statement statement;
    Connection koneksi;
    
    public RekapNilaiModel(RekapNilaiView view){
        this.view = view;
    }
    
    public void RekapNilai(){
        try {
                Class.forName("com.mysql.jdbc.Driver");
                koneksi = (com.mysql.jdbc.Connection)DriverManager.getConnection(DBurl, DBusername, DBpassword);
                statement = (com.mysql.jdbc.Statement)koneksi.createStatement();
                statement.executeUpdate("insert into rekapnilai values('"+ view.fmatkul.getText()
                        + "','" + Float.parseFloat(view.fnilaitugas.getText()) + "','" + 
                        Float.parseFloat(view.fnilaiuts.getText()) + "','" + 
                        Float.parseFloat(view.fnilaiuas.getText())+"')");          
                JOptionPane.showMessageDialog(null, "Data Berhasil Disimpan!", "Hasil", JOptionPane.INFORMATION_MESSAGE);
                ReloadTabel();
                koneksi.close();
                statement.close();
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(RekapNilaiView.class.getName()).log(Level.SEVERE, null, ex);
                JOptionPane.showMessageDialog(null, "Driver tidak ditemukan", "Hasil", JOptionPane.ERROR_MESSAGE);
            } catch (SQLException ex) {
                Logger.getLogger(RekapNilaiView.class.getName()).log(Level.SEVERE, null, ex);
                JOptionPane.showMessageDialog(null, "Data Gagal Disimpan!", "Hasil", JOptionPane.ERROR_MESSAGE);
            }
    }
    
    public void ReloadTabel() {
        view.dispose();
        LihatRekapNilaiView y = new LihatRekapNilaiView();
        LihatRekapNilaiModel u = new LihatRekapNilaiModel();
        LihatRekapNilaiController x = new LihatRekapNilaiController(y, u);
    }  
}

