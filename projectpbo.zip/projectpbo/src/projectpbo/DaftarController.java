package projectpbo;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class DaftarController {
        DaftarView vieww;
        
    DaftarController(DaftarView view){
        this.vieww = view;
        this.vieww.RekapButton(new Rekap());
        this.vieww.LihatRekapButton(new LihatRekap());
        this.vieww.TotalButton(new Total());
    }
               
    private class Rekap implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent ae) {
            RekapNilaiView u = new RekapNilaiView ();
            RekapNilaiModel v = new RekapNilaiModel(u);
            RekapNilaiController w = new RekapNilaiController (u,v);      
        }
    }
    
    private class LihatRekap implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent ae) {
            LihatRekapNilaiView y = new LihatRekapNilaiView();
            LihatRekapNilaiModel u = new LihatRekapNilaiModel();
            LihatRekapNilaiController x = new LihatRekapNilaiController(y, u);    
        }   
    }
    private class Total implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent ae) {
            TotalNilaiView o = new TotalNilaiView();
            TotalNilaiModel p = new TotalNilaiModel();
            TotalNilaiController z = new TotalNilaiController(o, p);     
        }
    }
}

