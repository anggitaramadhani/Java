package projectpbo;

import java.awt.FlowLayout;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class TotalNilaiView extends JFrame {
    String[][] rekapnilai = new String[100][2];
    String[] kolom = {"MataKuliah", "NilaiAkhir"};
    JTable tabel;
    JScrollPane scrollpane;
    JButton bmenu = new JButton("Menu");
    Float tugas[] = new Float[100], uas[] = new Float[100], uts[] = new Float[100], nilaiakhir[] = new Float[100];
    
    TotalNilaiView(){
        setTitle("Hasil");
        setSize(500,550);
        tabel = new JTable(rekapnilai,kolom);
        scrollpane = new JScrollPane(tabel);
        setLayout(new FlowLayout());
        tabel.getColumnModel().getColumn(0).setPreferredWidth(380);
        tabel.getColumnModel().getColumn(1).setPreferredWidth(120);
        add(scrollpane);
        add(bmenu);
        bmenu.setBounds(230, 530, 80, 20);
        setVisible(true);
        setLocationRelativeTo(null);  
        setDefaultCloseOperation (3);
    }
public void MenuButton(ActionListener j) {
        bmenu.addActionListener(j);
    }
}
