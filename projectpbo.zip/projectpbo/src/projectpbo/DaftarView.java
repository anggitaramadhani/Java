package projectpbo;

import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class DaftarView extends JFrame{
    JLabel lmenu = new JLabel ("MENU");
    JButton brekap = new JButton ("Rekap Nilai");
    JButton blihat = new JButton ("Lihat Data");
    JButton btotal = new JButton ("Nilai Akhir");
    JLabel background = new JLabel ();
    
    DaftarView(){
    setTitle("Menu");
    setLayout(null);
    setSize(310,350);
    setVisible(true);
    setLocationRelativeTo(null);
    setDefaultCloseOperation (3);
    
    add(lmenu);
    lmenu.setBounds(130, 80, 80, 30); 
    add(brekap);
    brekap.setBounds(100, 120, 100, 20);
    add(blihat);
    blihat.setBounds(100, 160, 100, 20);
    add(btotal);
    btotal.setBounds(100, 200, 100, 20);
    add(background);
    background.setIcon(new ImageIcon("C:\\Users\\Anggita\\Documents\\NetBeansProjects\\projectpbo\\gambar\\satu.jpg"));
    background.setBounds(0,0,310,350);
    }
    
    public void RekapButton(ActionListener b){
        brekap.addActionListener(b);
    }
    
    public void LihatRekapButton(ActionListener c){
        blihat.addActionListener(c);
    }
    
    public void TotalButton(ActionListener d){
        btotal.addActionListener(d);
    }
}
