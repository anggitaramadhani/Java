package projectpbo;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

public class LoginController {
    LoginView view;
    LoginModel model = new LoginModel();
    	LoginController(LoginView view){
        this.view = view;
        this.view.OKButton(new a());
        this.view.ResetButton(new b());
    	}
        private class a implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent a) {
                model.setUsername();
                model.setPassword();
                String Username = view.fusername.getText();
                String Password = view.fpassword.getText();
                if (Username.equals(model.getUsername()) && Password.equals(model.getPassword())) {
                    DaftarView x = new DaftarView();
                    DaftarController y = new DaftarController(x);
                } else {
                    JOptionPane.showConfirmDialog(null, "Login gagal!!!", "OK", JOptionPane.OK_OPTION);
                    view.fusername.setText("");
                    view.fpassword.setText("");
                }
            }
        }
    
    private class b implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent b) {
                view.frame.setLayout(null);
                view.fusername.setText("");
                view.fpassword.setText("");
            }
        }
    
    public static void main(String[] args){
        LoginView view = new LoginView();
        LoginController controller = new LoginController(view);
    } 
}

