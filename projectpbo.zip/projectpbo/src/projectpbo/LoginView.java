package projectpbo;

import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class LoginView {
    LoginModel model = new LoginModel();
    JFrame frame = new JFrame("Judul");
    JLabel llogin = new JLabel("Login");
    JLabel lusername = new JLabel("Username");
    JTextField fusername = new JTextField();
    JLabel lpassword = new JLabel("Password");
    JPasswordField fpassword = new JPasswordField();
    JButton bok = new JButton("OK");
    JButton breset = new JButton("Reset");
    JLabel background = new JLabel();

    LoginView() {      
        frame.setLayout(null);
        frame.setSize(300, 350);
        frame.setVisible(true);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation (3);
        frame.add(llogin);
        llogin.setBounds(130, 30, 60, 20); 
        frame.add(lusername);
        lusername.setBounds(20, 70, 60, 20);
        frame.add(fusername);
        fusername.setBounds(100, 70, 150, 20);
        frame.add(lpassword);
        lpassword.setBounds(20, 110, 60, 20);
        frame.add(fpassword);
        fpassword.setBounds(100, 110, 150, 20);
        frame.add(bok);
        bok.setBounds(150, 150, 60, 20);
        frame.add(breset);
        breset.setBounds(50, 150, 70, 20);
        frame.add(background);
        background.setIcon(new ImageIcon("C:\\Users\\Anggita\\Documents\\NetBeansProjects\\projectpbo\\gambar\\tiga.jpg"));
        background.setBounds(0,0,300,350);
    }

    public void OKButton(ActionListener a) {
        bok.addActionListener(a);
    }

    public void ResetButton(ActionListener b) {
        breset.addActionListener(b);
    }
}

