package projectpbo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class LihatRekapNilaiModel {
    String DBurl = "jdbc:mysql://localhost/datamahasiswa";
    String DBusername = "root";
    String DBpassword = "";
    Connection koneksi;
    Statement statement;
    ResultSet resultset;
    LihatRekapNilaiView view;
    String MataKuliah;
    
    public void Hapus(LihatRekapNilaiView view){
        try {
                Class.forName("com.mysql.jdbc.Driver");
                koneksi = DriverManager.getConnection(DBurl, DBusername, DBpassword);
                statement = koneksi.createStatement();
                String sql = "delete from rekapnilai where MataKuliah = '" + view.Fhapus.getText()
                        + "' or NilaiTugas = '" + view.Fhapus.getText() + "' or NilaiUTS = '"
                        + view.Fhapus.getText() + "' or NilaiUAS = '" + view.Fhapus.getText() + "'";
                statement.executeUpdate(sql);
                statement.close();
                koneksi.close();
                ReloadTabel(view);
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Data Gagal Ditemukan!!");
            } catch (ClassNotFoundException ex) {
                JOptionPane.showMessageDialog(null, "Driver Tidak Ditemukan!!");
            }
    }
    
    public void Edit(LihatRekapNilaiView view){
            MataKuliah = view.tabel.getValueAt(view.tabel.getSelectedRow(), 0).toString();
            String NilaiTugas = view.tabel.getValueAt(view.tabel.getSelectedRow(), 1).toString();
            String NilaiUTS = view.tabel.getValueAt(view.tabel.getSelectedRow(), 2).toString();
            String NilaiUAS = view.tabel.getValueAt(view.tabel.getSelectedRow(), 3).toString();
            view.fmatkul1.setText(MataKuliah);
            view.fnilaitugas1.setText(NilaiTugas);
            view.fnilaiuts1.setText(NilaiUTS);
            view.fnilaiuas1.setText(NilaiUAS);
    }
    public void Simpan(LihatRekapNilaiView view){
        try {
                Class.forName("com.mysql.jdbc.Driver");
                koneksi = DriverManager.getConnection(DBurl, DBusername, DBpassword);
                statement = koneksi.createStatement();
                statement.executeUpdate("insert into rekapnilai values('" + view.fmatkul1.getText() + "','"
                        + view.fnilaitugas1.getText() + "','" + view.fnilaiuts1.getText() + "','"
                        + view.fnilaiuas1.getText() + "')");
                JOptionPane.showMessageDialog(null, "Data Berhasil Disimpan!", "Hasil", JOptionPane.INFORMATION_MESSAGE);
                statement.close();
                koneksi.close();
                ReloadTabel(view);
} catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Data Gagal Ditemukan!!");
                } catch (ClassNotFoundException ex) {
                JOptionPane.showMessageDialog(null, "Driver Tidak Ditemukan!!");
            }
    }
    
    public void Update(LihatRekapNilaiView view){
        try {
                Class.forName("com.mysql.jdbc.Driver");
                koneksi = DriverManager.getConnection(DBurl, DBusername, DBpassword);
                statement = koneksi.createStatement();
                statement.execute("update rekapnilai set MataKuliah ='" + view.fmatkul1.getText()
                        + "' WHERE MataKuliah ='" + MataKuliah + "'");
                statement.execute("update rekapnilai set NilaiTugas ='" + view.fnilaitugas1.getText()
                        + "' WHERE MataKuliah ='" + MataKuliah + "'");
                statement.execute("update rekapnilai set NilaiUTS ='" + view.fnilaiuts1.getText()
                        + "' WHERE MataKuliah ='" + MataKuliah + "'");
                statement.execute("update rekapnilai set NilaiUAS ='" + view.fnilaiuas1.getText()
                        + "' WHERE MataKuliah ='" + MataKuliah + "'");
                statement.close();
                koneksi.close();
                JOptionPane.showMessageDialog(null, "Data Berhasil Diupdate!", "Hasil", JOptionPane.INFORMATION_MESSAGE);
                ReloadTabel(view);
            } catch (ClassNotFoundException ex) {
                JOptionPane.showMessageDialog(null, "Driver Tidak Ditemukan!!");
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Data Gagal Ditemukan!!");
                Logger.getLogger(LihatRekapNilaiController.class.getName()).log(Level.SEVERE, null, ex);
            }
    }
    
public void tabel(LihatRekapNilaiView view){
        try {
            Class.forName("com.mysql.jdbc.Driver");
            koneksi = DriverManager.getConnection(DBurl, DBusername, DBpassword);
            statement = koneksi.createStatement();
            String sql = "select * from rekapnilai";
            resultset = statement.executeQuery(sql);
            int a = 0;
            while (resultset.next()) {
                view.rekapnilai[a][0] = resultset.getString("MataKuliah");
                view.rekapnilai[a][1] = resultset.getString("NilaiTugas");
                view.rekapnilai[a][2] = resultset.getString("NilaiUTS");
                view.rekapnilai[a][3] = resultset.getString("NilaiUAS");
                a++;
            }
            statement.close();
            koneksi.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Data Gagal Ditemukan!!");
        } catch (ClassNotFoundException ex) {
            JOptionPane.showMessageDialog(null, "Driver Tidak Ditemukan!!");
        }
    }
    
     public void ReloadTabel(LihatRekapNilaiView view) {
        view.dispose();
        LihatRekapNilaiView y = new LihatRekapNilaiView();
        LihatRekapNilaiModel u = new LihatRekapNilaiModel();
        LihatRekapNilaiController x = new LihatRekapNilaiController(y, u);
    }
} 


