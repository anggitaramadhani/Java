package projectpbo;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TotalNilaiController {
    TotalNilaiView view;
    TotalNilaiModel model;
    
    TotalNilaiController(TotalNilaiView view, TotalNilaiModel model){
        this.view = view;
        this.model = model;
        this.model.TotalNilai(view);
        this.view.MenuButton(new j());
    }
    
    private class j implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent ae) {
            DaftarView x = new DaftarView();
            DaftarController y = new DaftarController(x);
        }
    }
}
