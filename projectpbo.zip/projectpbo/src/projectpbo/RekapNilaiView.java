package projectpbo;

import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class RekapNilaiView extends JFrame{   
    JLabel lrekapnilai = new JLabel ("REKAP NILAI");
    JLabel lmatkul = new JLabel ("Mata Kuliah");
    JTextField fmatkul = new JTextField ();
    JLabel lnilaitugas = new JLabel ("Nilai Tugas");
    JTextField fnilaitugas = new JTextField ();
    JLabel lnilaiuts = new JLabel ("Nilai UTS");
    JTextField fnilaiuts = new JTextField ();
    JLabel lnilaiuas = new JLabel ("Nilai UAS");
    JTextField fnilaiuas = new JTextField ();
    JButton binput = new JButton ("Input");
    JLabel background = new JLabel();
    JButton bmenu = new JButton("Menu");
    
    RekapNilaiView(){
    setTitle("Rekap");
    setLayout (null);
    setSize (300,450);
    setVisible (true);
    setDefaultCloseOperation (3);
    setLocationRelativeTo(null);
    add(lrekapnilai);
    lrekapnilai.setBounds(100, 30, 180, 20);
    add(lmatkul);
    lmatkul.setBounds(20, 70, 90, 20); 
    add(fmatkul);
    fmatkul.setBounds(110, 70, 150, 20);
    add(lnilaitugas);
    lnilaitugas.setBounds(20, 110, 90, 20);
    add(fnilaitugas);
    fnilaitugas.setBounds(110, 110, 35, 20);
    add(lnilaiuts);
    lnilaiuts.setBounds(20, 150, 90, 20);
    add(fnilaiuts);
    fnilaiuts.setBounds(110, 150, 35, 20);
    add(lnilaiuas);
    lnilaiuas.setBounds(20, 190, 90, 20);
    add(fnilaiuas);
    fnilaiuas.setBounds(110, 190, 35, 20);
    add(binput);
    binput.setBounds(100, 230, 80, 20); 
    add(bmenu);
    bmenu.setBounds(100, 270, 80, 20);
    add(background);
    background.setIcon(new ImageIcon("C:\\Users\\Anggita\\Documents\\NetBeansProjects\\projectpbo\\gambar\\empat.jpg"));
    background.setBounds(0,0,300,450);
}
    
    public void InputButton(ActionListener a){
        binput.addActionListener(a);
    }
    
    public void MenuButton(ActionListener j) {
        bmenu.addActionListener(j);
    }
}

