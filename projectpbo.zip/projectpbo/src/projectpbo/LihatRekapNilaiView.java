package projectpbo;

import java.awt.FlowLayout;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

public class LihatRekapNilaiView extends JFrame {
    String[][] rekapnilai = new String[500][4];
    String[] kolom = {"MataKuliah", "NilaiTugas", "NilaiUTS", "NilaiUAS"};
    JTable tabel;
    JTextField Fhapus;
    JButton Bmenu;
    JButton Binput;
    JButton Bhapus;
    JButton Bedit;
    JButton Bsimpan;
    JButton Bupdate;
    JScrollPane scrollpane;
    public JTextField fmatkul1;
    public JTextField fnilaitugas1;
    public JTextField fnilaiuts1;
    public JTextField fnilaiuas1;
    LihatRekapNilaiController controller;

LihatRekapNilaiView() {
        setTitle("Lihat Rekap Nilai");
        setSize(500, 550);
        tabel = new JTable(rekapnilai, kolom);
        scrollpane = new JScrollPane(tabel);
        Fhapus = new JTextField(20);
        Bmenu = new JButton("Menu");
        Binput = new JButton("Input");
        Bhapus = new JButton("Hapus");
        fmatkul1 = new JTextField(8);
        fnilaitugas1 = new JTextField(3);
        fnilaiuts1 = new JTextField(3);
        fnilaiuas1 = new JTextField(3);
        Bedit = new JButton("Edit");
        Bsimpan = new JButton("Simpan");
        Bupdate = new JButton("Update");
        setLayout(new FlowLayout());
        add(scrollpane);
        add(Fhapus);
        add(Bhapus);
        add(Binput);
        add(Bmenu);
        add(fmatkul1);
        add(fnilaitugas1);
        add(fnilaiuts1);
        add(fnilaiuas1);
        add(Bedit);
        add(Bsimpan);
        add(Bupdate);
        setLayout(new FlowLayout());
        tabel.getColumnModel().getColumn(0).setPreferredWidth(230);
        tabel.getColumnModel().getColumn(1).setPreferredWidth(90);
        tabel.getColumnModel().getColumn(2).setPreferredWidth(90);
        tabel.getColumnModel().getColumn(3).setPreferredWidth(90);
        add(scrollpane);
        setVisible(true);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(3);
    }

    public void InputButton(ActionListener i) {
        Binput.addActionListener(i);
    } 

    public void MenuButton(ActionListener j) {
        Bmenu.addActionListener(j);
    }
    
    public void HapusButton(ActionListener k) {
        Bhapus.addActionListener(k);
    }
    
    public void EditButton(ActionListener l) {
        Bedit.addActionListener(l);
    }
    
    public void SimpanButton(ActionListener m) {
        Bsimpan.addActionListener(m);
    }
    
    public void UpdateButton(ActionListener n) {
        Bupdate.addActionListener(n);
    }
} 


