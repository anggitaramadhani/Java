package projectpbo;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class LihatRekapNilaiController {
    String DBurl = "jdbc:mysql://localhost/datamahasiswa";
    String DBusername = "root";
    String DBpassword = "";
    Connection koneksi;
    Statement statement;
    ResultSet resultset;
    LihatRekapNilaiView view;
    LihatRekapNilaiModel model;
    LihatRekapNilaiController(LihatRekapNilaiView view, LihatRekapNilaiModel model) {
        this.view = view;
        this.model = model;
        model.tabel(view);
        this.view.InputButton(new i());
        this.view.MenuButton(new j());
        this.view.HapusButton(new k());
        this.view.EditButton(new l());
        this.view.SimpanButton(new m());
        this.view.UpdateButton(new n());
    }

    private class i implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent ae) {
            RekapNilaiView u = new RekapNilaiView ();
            RekapNilaiModel v = new RekapNilaiModel (u);
            RekapNilaiController w = new RekapNilaiController (u, v);
        }
    }

    private class j implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent ae) {
            DaftarView x = new DaftarView();
            DaftarController y = new DaftarController(x);
        }
    }

    private class k implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent ae) {
            model.Hapus(view);
        }
    }

    private class l implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent ae) {
            model.Edit(view);
        }
    }

    private class m implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent ae) {
            model.Simpan(view);
        }
    }

    private class n implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent ae) {
            model.Update(view);
        }
    }
}
