package projectpbo;

public class LoginModel {
    private String Username, Password;
    boolean value;
    
    public String getUsername() {
        return Username;
    }

    public void setUsername() {
        Username = "anggita";
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword() {
        Password = "1999";
    }

    public void setvalue(boolean value) {
        this.value = value;
    }

    public boolean getvalue() {
        return value;
    }
}

