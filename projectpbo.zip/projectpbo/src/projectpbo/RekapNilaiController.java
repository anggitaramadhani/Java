package projectpbo;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.Statement;

public class RekapNilaiController {
    String DBurl = "jdbc:mysql://localhost/datamahasiswa";
    String DBusername = "root";
    String DBpassword = "";
    Connection koneksi;
    Statement statement;
    RekapNilaiView view;
    RekapNilaiModel model;

    RekapNilaiController(RekapNilaiView view, RekapNilaiModel model){
        this.view = view;
        this.view.InputButton(new a());
        this.view.MenuButton(new j());
        this.model = model;
    }  

    private class j implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent ae) {
            DaftarView x = new DaftarView();
            DaftarController y = new DaftarController(x);
        }
    }
    private class a implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent ae) {
            model.RekapNilai();
        }
    }
}

